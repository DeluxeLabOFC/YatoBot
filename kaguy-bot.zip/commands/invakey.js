const Discord = require('discord.js') 
const db = require('quick.db')

module.exports.run = async(client, message, args) =>{
  if(message.author.id === '681532724045283429'){
message.delete()
if(!args[0]) return message.reply('qual codigo você quer usa?')
let code = db.fetch(`${args[0]}_756685535195562075`)
if(code === null || code === 0) return message.reply('codigo invalido!')

let limite = db.fetch(`${args[0]}v_756685535195562075`)

let server = client.guilds.cache.get('756685535195562075')
let member = server.members.cache.get(message.author.id)
if(!member) return message.reply('codigo so funciona se você estive no servidor de suporte!')
let role = server.roles.cache.get(code)
let canal = server.channels.cache.get('761691189207760937')


db.set(`${args[0]}_756685535195562075`, 0)
db.set(`${args[0]}o__756685535195562075`, null)
db.set(`${args[0]}v_756685535195562075`, null)
message.reply(`codigo invalidado com sucesso!`)
  }else if(message.author.id === "427612840078213120"){
message.delete()
if(!args[0]) return message.reply('qual codigo você quer usa?')
let code = db.fetch(`${args[0]}_756685535195562075`)
if(code === null || code === 0) return message.reply('codigo invalido!')

let limite = db.fetch(`${args[0]}v_756685535195562075`)

let server = client.guilds.cache.get('756685535195562075')
let member = server.members.cache.get(message.author.id)
if(!member) return message.reply('codigo so funciona se você estive no servidor de suporte!')
let role = server.roles.cache.get(code)
let canal = server.channels.cache.get('761691189207760937')


db.set(`${args[0]}_756685535195562075`, 0)
db.set(`${args[0]}o__756685535195562075`, null)
db.set(`${args[0]}v_756685535195562075`, null)
message.reply(`codigo invalidado com sucesso!`)
  }else return message.reply('so para os devs!')
}