const db = require('quick.db')
const Discord = require('discord.js')


exports.run = async (client, message, args) => {

   if (message.author.id === '681532724045283429' || message.author.id === '427612840078213120'){

    let user = message.mentions.members.first() || message.author

    if (isNaN(args[0])) return message.channel.send(`${message.author}, você precisa inserir um número válido para remover.`)
    db.subtract(`KaCoins_${user.id}`, args[0])
    let bal = await db.fetch(`KaCoins_${user.id}`)

    let embed = new Discord.RichEmbed()
    .setAuthor(`Dinheiro removido!`, message.author.displayAvatarURL)
    .addField(`Amount`, `${args[0]}$`)
    .addField(`Saldo Atualizado`, `${bal}$`)
    .setColor("RANDOM") 
    .setTimestamp()
 
    message.channel.send(embed)




   }else return message.reply('so os devs!')
}