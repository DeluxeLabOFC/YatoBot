const Discord = require("discord.js");
const api = require("nekos.life");
const nekos = new api()

exports.run = async(client,message,args) => {
    let membro = message.mentions.users.first() || client.users.cache.get(args[0])
    nekos.sfw.slap().then(async neko => {
        let msg = `${message.author} meteu um tapa em ${membro}`
        const embed = new Discord.MessageEmbed()
        if(!membro) return message.reply(`Pra que tanto odio de si mesmo... ,_,`)
        if(membro === client.user) message.reply(`Ta se metendo no caminho errado -_-`)
        embed.setDescription(msg)
        embed.setImage(neko.url)
        message.channel.send(embed)
    })
}

exports.help = {
    name: "slap",
    aliases: "tapa"
}