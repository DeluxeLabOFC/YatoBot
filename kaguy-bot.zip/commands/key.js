const Discord = require('discord.js') 
const db = require('quick.db')

module.exports.run = async(client, message, args) =>{
message.delete()
if(!args[0]) return message.reply('qual codigo você quer usa?')
let code = db.fetch(`${args[0]}_756685535195562075`)
if(code === null || code === 0) return message.reply('codigo invalido!')

let limite = db.fetch(`${args[0]}v_756685535195562075`)

let server = client.guilds.cache.get('756685535195562075')
let member = server.members.cache.get(message.author.id)
if(!member) return message.reply('codigo so funciona se você estive no servidor de suporte!')
let role = server.roles.cache.get(code)
let canal = server.channels.cache.get('761691189207760937')
if(member.roles.cache.has(code)) return message.reply('você ja tem esse cargo!')

if(limite === 1){
db.set(`${args[0]}_756685535195562075`, 0)
db.set(`${args[0]}o__756685535195562075`, null)
message.reply(`codigo usado com sucesso!`)
member.roles.add(role)
let user = message.author
let roi = 0;
let embed = new Discord.MessageEmbed()

.setAuthor(`${message.author.tag}`,user.avatarURL())
.addField(`usuario que usou o codigo`, message.author)
.addField(`codigo`, args[0])
.addField(`pode usa`, roi)
canal.send(embed)
return
}else { 
message.reply(`codigo usado com sucesso!`)
member.roles.add(role)

let teste =  Math.floor(limite - 1)
db.set(`${args[0]}v_756685535195562075`, teste)
let userr = message.author
let e = new Discord.MessageEmbed()
.setAuthor(`${message.author.tag}` ,userr.avatarURL())
.addField(`usuario que usou o codigo`, message.author)
.addField(`codigo`, args[0])
.addField(`pode usa`, `${limite - 1}`)
canal.send(e)
}
}