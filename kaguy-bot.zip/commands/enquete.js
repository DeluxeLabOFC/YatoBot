const Discord = require("discord.js");
let db = require('quick.db')
module.exports.run = async (client, message, args) => {
    let oi = message.guild.id
  let prefix = db.get(`prefix_${oi}`) || 'k"';
  if(prefix === null) prefix = "k"
    if (!message.member.permissions.has("ADMINISTRATOR"))
      return message.channel.send(
        `você não tem admin, ${message.author.username}`
      );
    const channel =
      message.mentions.channels.first() ||
      message.guild.channels.cache.get(args[0]);
    if (!channel) {
      return message.channel.send(
        `Você não mencionou / deu o id do seu canal!`
      );
    }
    let question = message.content
      .split(`${prefix}enquete ${channel} `)
      .join("");
    if (!question)
      return message.channel.send(`Você não especificou seu enquete!`);
    const Embed = new Discord.MessageEmbed()
      .setTitle(`Nova enquete!`)
      .setDescription(`${question}`)
      .setFooter(`${message.author.username} criou esta enquete.`)
      .setColor(`RANDOM`);
    let msg = await client.channels.cache.get(channel.id).send(Embed);
    await msg.react("👍");
    await msg.react("👎");
};