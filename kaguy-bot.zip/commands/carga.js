const Discord = require('discord.js')

module.exports.run = async(client, message, args) => {
        const embed = new Discord.MessageEmbed()
.setTitle(`Comando em manutenção`)
.setDescription(`Manutenção`)
message.channel.send (embed)
}