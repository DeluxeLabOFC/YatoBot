const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async (client, message, args) => {
   if (message.author.id === '681532724045283429' || message.author.id === '427612840078213120'){
  
    if (!args[0]) return message.reply('Especifique um valor a adicionar.')
    if (isNaN(args[0])) return message.reply('Esse não era um número válido!')

    let user = message.mentions.users.first() || message.author
    message.channel.send('Adicionado com sucesso ' + args[0] + ' para ' + `${user}`)
    db.add(`KaCoins_${user.id}`, args[0])

}else return message.reply('so os devs!')
}