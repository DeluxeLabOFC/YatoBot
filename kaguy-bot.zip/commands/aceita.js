const Discord = require('discord.js')
const db = require('quick.db')
const config = require('../config.json')
module.exports.run = async(client, message, args) => {
  if(message.guild.id !== config.suporte) return message.reply('so para o servidor de suporte!')
let hi = message.guild.members.cache.get(args[0])
if(!hi) return message.reply('membro invalido!')
let hey = db.fetch(`id_${hi.id}`)
if(hey === null || hey === 0) return message.reply('esse usuario não pediu para entra no jogo!')
let roi = db.fetch(`channelid_${message.author.id}`)
if(roi === null || roi === 0)return message.reply('você ainda não tem um jogo para aceita esse membro!')

let owner = db.fetch(`owner_${message.author.id}`)
if(owner !== roi) return message.reply('você não é o dono desse jogo para aceita esse membro!')//testa denovo

let roleid = db.fetch(`roleid_${message.author.id}`)
if(roleid === null || roleid === 0) return message.reply('você não é o dono desse jogo para aceita esse membro!')
let role = message.guild.roles.cache.get(roleid)
hi.roles.add(role)
hi.send(`${hi} o ${message.author} aceitou você no jogo!`)
}
