const Discord = require('discord.js')
const db = require('quick.db')
const config = require('../config.json')
module.exports.run = async(client, message, args) => {
  if(message.guild.id !== config.suporte) return message.reply('so para o servidor de suporte!')
        const embed = new Discord.MessageEmbed()
.setTitle(`Comando em manutenção`)
.setDescription(`Coloque o code de seu amigo e espere ele aceitar sua entrada`)
message.channel.send(embed)

if(!args[0]) return message.reply('porfavor coloque o code de um amigo seu!')
let hey = db.fetch(`code_${args[0]}`)
if(hey === 0 || hey === null) return message.reply('codigo invalido!')

let hi = message.guild.channels.cache.get(hey)
if(!hi) return message.reply('codigo invalido! ou teve um erro!')

hi.send('seu amigo quer entra na sua patida! ' + `<@${message.author.id}>` + ' para aceita coloque k!aceita ' + message.author.id + ' para aceita!')
message.channel.send(`${message.author}, seu pedido para entra foi enviado!`)
db.set(`id_${message.author.id}`, args[0])
}
