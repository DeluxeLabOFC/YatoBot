const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {     
   const embed = new Discord.MessageEmbed()
.setTitle(`Ping?`)
.setDescription(`•\`Latência do server:\`•\n**${Date.now() - message.createdTimestamp}ms.**\n•\`Latência da API:\`•\n**${Math.round(
        client.ws.ping
      )}ms.**`)
message.channel.send (embed)
}