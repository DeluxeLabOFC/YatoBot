  

 const Discord = require('discord.js')
  module.exports.run = async(client, message, args) => {
  const donos = ['681532724045283429', '427612840078213120']
        
if(!(await donos.includes(message.author.id))) return message.channel.send('so os devs!!');
        let code = args.join(' ')
        if(!code) return message.channel.send('argumento');
       if(code.includes('token')) return message.reply('O SEU DEV DESGRAÇADO EU NUM POSSO MANDA MEU TOKEN!');
 
        try {
            let resultado = await eval(code)
            var tipo = typeof(resultado)
 
            let embed = new Discord.MessageEmbed()
             .addField('Código', '```js\n' + `${code}` + '\n```', false)
             .addField('Resultado', '```js\n' + `${resultado}` + '\n```', false)
             .addField('Tipo', '```js\n' + `${tipo}` + '\n```', false)
             .setColor("#383838")
            message.channel.send(embed)
        } catch(err) {
            let embed = new Discord.MessageEmbed()
             .addField('Código', '```js\n' + `${code}` + '\n```', false)
             .addField('Erro', '```js\n' + `${err}` + '\n```', false)
             .setColor("#383838")
            message.channel.send(embed)
   }
  }