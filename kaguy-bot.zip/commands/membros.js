const Discord = require('discord.js')

exports.run = async (client, message, args) => {
  let embed = new Discord.MessageEmbed() 
    .setColor(`RANDOM`) 
    .setTitle(`No total temos`)
    .setDescription(`${client.users.cache.size} membros!!`)
    .setFooter(`Autor: ${message.author.tag} :D`, message.author.displayAvatarURL({format: "png"}));
 await message.channel.send(embed); 

};