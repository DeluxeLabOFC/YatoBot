const { MessageEmbed } = require("discord.js");
const ms = require("ms");
module.exports.run = async (bot, message, args) => {
    if (!message.member.permissions.has("ADMINSTRADOR")) return message.reply('sem permisão')
    if (!args[0]) return message.channel.send(`você não especificou o premium!`);
    if (
     
      !args[0].endsWith("d") &&
      !args[0].endsWith("h") &&
      !args[0].endsWith("m") &&
    !args[0].endsWith("s") )
      return message.channel.send(
        `você não usou o formato certo!`
      );
    if (isNaN(args[0][0])) return message.channel.send(`aquilo não é um numero!`);
    let channel = message.mentions.channels.first();
    if (!channel)
      return message.channel.send(
        `eu não pudi acha esse canal!`
      );
    let prize = args.slice(2).join(" ");
    if (!prize) return message.channel.send(`nenhum premium especificado`);
    message.channel.send(`*Sorteio criador em ${channel}*`);
    let Embed = new MessageEmbed()
      .setTitle(`Novo Sorteio!!!`)
    .setDescription('clique em 🎉  para participa!')
      .addField(`Premium`, prize, true)
    .addField(`Sorteiador`, message.author,true)
    .addField(`tempo` , args[1],true)
      .setTimestamp(Date.now() + ms(args[0]))
      .setColor(`RANDOM`);
    let m = await channel.send(Embed);
    m.react("🎉");
    setTimeout(() => {
      if (m.reactions.cache.get("🎉").count <= 1) {
        message.channel.send(`Reactions: ${m.reactions.cache.get("🎉").count}`);
        return message.channel.send(
          `não podi escolhe o ganhador!`
        );
      }

      let winner = m.reactions.cache
        .get("🎉")
        .users.cache.filter((u) => !u.bot)
        .random();
      channel.send(
        `o ganhado do **${prize}** é... ${winner}`
      );
    }, ms(args[0]));
  };