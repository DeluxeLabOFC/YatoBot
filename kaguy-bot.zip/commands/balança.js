const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async(client, message, args) => {
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if(!user) {
  user = message.author
}

let coin = db.fetch(`KaCoins_${user.id}`)
if(coin === null) coin = 0
 
 let embed = new Discord.MessageEmbed()
.setColor("RANDOM")
.setDescription(`${user} tem ${coin} de KaCoins💰`)
message.channel.send(embed)
};
