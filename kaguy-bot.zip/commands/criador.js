const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {     
        const embed = new Discord.MessageEmbed()
.setTitle(`Saiba quem me criou`)
.setDescription(`Olá ${message.author}... meus criadores são jose_trindade1#4464 e Obvermos#0018`)
.addField('jose_trindade1#4464', 'fez 95%')
.addField('Obvermos#0018', 'fez 5%')
.setFooter(`jose_trindade1#4464 fez as coisas mais dificies`)
message.channel.send (embed)
}