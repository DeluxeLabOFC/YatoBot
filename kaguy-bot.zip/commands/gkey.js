const Discord = require('discord.js')
const db = require('quick.db')
let discord = Discord
module.exports.run = async(client, message, args) =>{
  if(message.author.id === '681532724045283429') {

if(message.guild.id !== "756685535195562075") return message.reply('o dev pq tu ta usando esse comando? tu sabe que ele so funciona quando tu esta no servidor de suporte né?')
let min = "100000"
let max = "999999"
let result = Math.floor(Math.random() * (max - min)) + min;
if(!args[0]) return message.reply('porfavor coloque o id de um cargo para pode coloca no key!')
let limite;
if(!args[1]) limite = 1
limite = args[1]
if(isNaN(limite)) limite = 1
if(limite === 0) limite = 1
 if (message.content.startsWith(`-`)) limite = 1
let role = message.guild.roles.cache.get(args[0])
if(!role) return message.reply('id de cargo invalido!')
    let o = role.id
    message.author.send(`${message.author}, aqui o seu key! ${result}\n\ premium: ${role.name} \n\ com limite de: ${limite} pessoas!`)
db.set(`${result}_756685535195562075`, o)
db.set(`${result}v_756685535195562075`, limite)
message.channel.send('olha as mensages privatas!')
db.set(`${result}o__756685535195562075`, message.author.id)
}else if(message.author.id === "427612840078213120"){
if(message.guild.id !== "756685535195562075") return message.reply('o dev pq tu ta usando esse comando? tu sabe que ele so funciona quando tu esta no servidor de suporte né?')
let min = "100000"
let max = "999999"
let result = Math.floor(Math.random() * (max - min)) + min;
if(!args[0]) return message.reply('porfavor coloque o id de um cargo para pode coloca no key!')
let limite;
if(!args[1]) limite = 1
limite = args[1]
if(isNaN(limite)) limite = 1
if(limite === 0) limite = 1
 if (message.content.startsWith(`-`)) limite = 1
let role = message.guild.roles.cache.get(args[0])//e ai
if(!role) return message.reply('id de cargo invalido!')
    let o = role.id
    message.author.send(`${message.author}, aqui o seu key! ${result}\n\ premium: ${role.name} \n\ com limite de: ${limite} pessoas!`)
db.set(`${result}_756685535195562075`, o)
db.set(`${result}v_756685535195562075`, limite)
db.set(`${result}o__756685535195562075`, message.author.id)
message.channel.send('olha as mensagens privadas!')

} else return message.reply('so os devs!!')
}