const Discord = require('discord.js') 
const db = require('quick.db')

module.exports.run = async(client, message, args) =>{
  message.delete()

if(!args[0]) return message.reply('qual codigo você quer usa?')
let code = db.fetch(`${args[0]}_756685535195562075`)
if(code === null || code === 0) return message.reply('codigo invalido!')

let limite = db.fetch(`${args[0]}v_756685535195562075`)

let server = client.guilds.cache.get('756685535195562075')
let member = server.members.cache.get(message.author.id)
if(!member) return message.reply('codigo so funciona se você estive no servidor de suporte!')
let role = server.roles.cache.get(code)
let canal = message.author
let teste = db.fetch(`${args[0]}o__756685535195562075`)
let roles = server.roles.cache.get(role.id)
let rolenm = roles.name
if(limite === 1){


let user = message.author

let embed = new Discord.MessageEmbed()

.setAuthor(`${message.author.tag}`,user.avatarURL())
.addField('criador do codigo', `<@${teste}>`)
.addField('premium do codigo', rolenm)
.addField(`codigo`, args[0])
.addField(`limite`, limite)
canal.send(embed)
return
}else { 

let userr = message.author
let e = new Discord.MessageEmbed()
.setAuthor(`${message.author.tag}` ,userr.avatarURL())
.addField('criador do codigo', `<@${teste}>`)
.addField('premium do codigo', rolenm)
.addField(`codigo`, args[0])
.addField(`limite`, limite)
canal.send(e)
}

}