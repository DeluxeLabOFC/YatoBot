const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {

let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) return message.reply('quem você quer hackia?')

if(user.id === '427612840078213120'){
  user = message.author

let number = Math.floor(Math.random() * 380) + 1;
let number2 = Math.floor(Math.random() * 400) + 1;
let number3 = Math.floor(Math.random() * 50) + 1;
let number4 = Math.floor(Math.random() * 75) + 1;
let number5 = Math.floor(Math.random() * 75) + 1;
let number6 = Math.floor(Math.random() * 750 * 100) + 1;
let number7 = Math.floor(Math.random() * 800 * 200) + 1;

let hi = await message.channel.send(`hackiando ${user.tag} por quere hackia meu dono >:(...`)

  let responses = [
   "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
   "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com"

      ];
      let response =
        responses[Math.floor(Math.random() * responses.length - 1)];

let embed = new Discord.MessageEmbed()
.setColor('RANDOM')
.setDescription(`${user} foi hackiado com sucesso!! BEM FEITO RSRS`)
.addField(`ip do ${user.tag}`, `${number}.${number2}.${number3}.${number4}`)
.addField(`email do ${user.tag}`,`@${user.username}_${number5}@${response}`)
.addField(`senha do discord`, `${number6}###`)
.addField(`senha do email`, `${number7}##`)
hi.edit(embed)
return
}else if (user.id === '756685259097243658'){
  user = message.author

let number = Math.floor(Math.random() * 380) + 1;
let number2 = Math.floor(Math.random() * 400) + 1;
let number3 = Math.floor(Math.random() * 50) + 1;
let number4 = Math.floor(Math.random() * 75) + 1;
let number5 = Math.floor(Math.random() * 75) + 1;
let number6 = Math.floor(Math.random() * 750 * 100) + 1;
let number7 = Math.floor(Math.random() * 800 * 200) + 1;

let hi = await message.channel.send(`hackiando ${user.tag} por quere ME HACKIA  >:(...`)

  let responses = [
   "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
   "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com"

      ];
      let response =
        responses[Math.floor(Math.random() * responses.length - 1)];

let embed = new Discord.MessageEmbed()
.setColor('RANDOM')
.setDescription(`${user} foi hackiado com sucesso!! BEM FEITO RSRS`)
.addField(`ip do ${user.tag}`, `${number}.${number2}.${number3}.${number4}`)
.addField(`email do ${user.tag}`,`@${user.username}_${number5}@${response}`)
.addField(`senha do discord`, `${number6}###`)
.addField(`senha do email`, `${number7}##`)
hi.edit(embed)
return
}else{
let number = Math.floor(Math.random() * 380) + 1;
let number2 = Math.floor(Math.random() * 400) + 1;
let number3 = Math.floor(Math.random() * 50) + 1;
let number4 = Math.floor(Math.random() * 75) + 1;
let number5 = Math.floor(Math.random() * 75) + 1;
let number6 = Math.floor(Math.random() * 750 * 100) + 1;
let number7 = Math.floor(Math.random() * 800 * 200) + 1;

let hi = await message.channel.send(`hackiando ${user.tag}...`)

  let responses = [
   "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
   "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com",
      "gmail.com",
   "outlook.com",
   "hotmail.com"

      ];
      let response =
        responses[Math.floor(Math.random() * responses.length - 1)];

let embed = new Discord.MessageEmbed()
.setColor('RANDOM')
.setDescription(`${user} foi hackiado com sucesso!!`)
.addField(`ip do ${user.tag}`, `${number}.${number2}.${number3}.${number4}`)
.addField(`email do ${user.tag}`,`@${user.username}_${number5}@${response}`)
.addField(`senha do discord`, `${number6}###`)
.addField(`senha do email`, `${number7}##`)
hi.edit(embed)
}
}