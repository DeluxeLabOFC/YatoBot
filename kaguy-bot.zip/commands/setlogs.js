const Discord = require('discord.js');
const db = require('quick.db')

module.exports.run = async (client, message, args) => {
      if (!message.member.hasPermission('ADMINISTRATOR')) return message.reply('Parece que vocé não tem permissões') // assim ta bom??
let server = message.guild
  let id = message.guild.channels.cache.get(args[0]) || message.mentions.channels.first();
  if(!id) message.reply('cade o canal ou o id do canal??')
  message.channel.send('canal logs mudado para ' + `${id}`)
  db.set(`id3_${server.id}`, id.id) // pronto ta feito :D
  
};
