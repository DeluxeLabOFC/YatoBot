const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {
const paginationEmbed = require('discord.js-pagination');

let messsagembed = new Discord.MessageEmbed()
.setTitle('plano.')
.setDescription(`plano - 🐭\`rato\` \n\ preço - <:Money:762450228132446258>\`2,50$\` \n\ beneficios - \`(em breve)\``)

let messsagembed2 = new Discord.MessageEmbed()
.setTitle('plano.')
.setDescription(`plano - <:ouro:762458131442696204>\`ouro\` \n\preço - <:Money:762450228132446258>\`5$\` \n\ beneficios - \`(em breve)\``)

let messsagembed3 = new Discord.MessageEmbed()
.setTitle('plano.')
.setDescription(`plano - <:diamante:762458132189413416>\`diamante\` \n\preço - <:Money:762450228132446258>\`10$\` \n\ beneficios - \`(em breve)\``)

pages = [
    messsagembed,
    messsagembed2,
    messsagembed3
];
let emoji1 = '⏪'
let emoji2 = '⏩'
let emojiList = [emoji1 , emoji2]
paginationEmbed(message, pages, emojiList);

}