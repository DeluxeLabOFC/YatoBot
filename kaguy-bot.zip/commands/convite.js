const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {

        const embed = new Discord.MessageEmbed()
.setTitle(`Querendo me adicionar...`)
.setDescription(`No seu server :hearts: : [Add_Bot](https://discord.com/api/oauth2/authorize?client_id=756685259097243658&permissions=8&scope=bot)`)
.setFooter(`${client.guilds.cache.size} total de servidores`)
message.channel.send (embed)
}