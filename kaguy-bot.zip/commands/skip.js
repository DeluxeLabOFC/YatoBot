const { canModifyQueue } = require("../util/EvobotUtil");

module.exports.run = async(client, message, args) => {
    const queue = message.client.queue.get(message.guild.id);
    if (!queue)
      return message.reply("não tem nada tocando que eu posso pula para você.").catch(console.error);
    if (!canModifyQueue(message.member)) return;

    queue.playing = true;
    queue.connection.dispatcher.end();
    queue.textChannel.send(`${message.author} ⏭ skipado a musica`).catch(console.error);
  };