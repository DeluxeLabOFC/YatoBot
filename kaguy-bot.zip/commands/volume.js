const { canModifyQueue } = require("../util/EvobotUtil");

module.exports.run = async(client, message, args) =>{
const server = client.guilds.cache.get('756685535195562075')
const role = server.roles.cache.get('757713889327710277')
const member = server.members.cache.get(message.author.id)
if(!member) return message.reply('so para os planos rato!')
if(!member.roles.cache.has(role.id)) return message.reply('so para os planos rato!')
    const queue = message.client.queue.get(message.guild.id);

    if (!queue) return message.reply("não a nada tocando.").catch(console.error);
    if (!canModifyQueue(message.member))
      return message.reply("você precisa entra em uma canal de voz primeiro!").catch(console.error);

    if (!args[0]) return message.reply(`🔊 o volume atual é: **${queue.volume}%**`).catch(console.error);
    if (isNaN(args[0])) return message.reply("porfavor use um numero para coloca no volume.").catch(console.error);
    if (parseInt(args[0]) > 100 || parseInt(args[0]) < 0)
      return message.reply("porfavor use um numero de 0 a 100.").catch(console.error);

    queue.volume = args[0];
    queue.connection.dispatcher.setVolumeLogarithmic(args[0] / 100);

    return queue.textChannel.send(`Volume colocado para: **${args[0]}%**`).catch(console.error);
  };