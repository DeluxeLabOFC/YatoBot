const Discord = require('discord.js')
const axios = require('axios')

module.exports.run = async (client, message, args) =>{
  const url = "https://discordapp.com/api/v6/invite/BXN9HZ5?with_counts=true"
  let response, data;
        try {
            response = await axios.get(url);
             data = response.data;
        } catch (e) {
            return message.channel.send(`error`)
        }

        let embed = new Discord.MessageEmbed() 
    .setColor(`RANDOM`) 
    .setTitle(`Membros SK`)
    .setDescription(`No Server Suporte temos : ${data.approximate_member_count}`)
    .setFooter(`Autor: ${message.author.tag} :D`, message.author.displayAvatarURL({format: "png"}));
 await message.channel.send(embed); 
}