const Discord = require('discord.js')

module.exports.run = async(client, message, args) => {
let id = message.author.id
let embed = new Discord.MessageEmbed()
.setColor('RANDOM')
.setDescription(`${message.author} seu id é... ${id}`)
message.channel.send(embed)
}