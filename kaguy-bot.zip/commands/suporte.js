const Discord = require('discord.js')
const axios = require('axios')

module.exports.run = async (client, message, args) =>{
  const url = "https://discordapp.com/api/v6/invite/BXN9HZ5?with_counts=true"
  let response, data;
        try {
            response = await axios.get(url);
             data = response.data;
        } catch (e) {
            return message.channel.send(`error`)
        }

        const embed = new Discord.MessageEmbed()
.setTitle(`Quer suporte ai está`)
.setDescription(`Meu server para suporte : [Server](https://discord.gg/7bgx3y9)`)
.setFooter(`total membros: ${data.approximate_member_count}`)
message.channel.send (embed)
}