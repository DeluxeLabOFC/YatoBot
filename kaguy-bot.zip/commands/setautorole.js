const Discord = require('discord.js');
const db = require('quick.db')

module.exports.run = async (client, message, args) => {
      if (!message.member.hasPermission('ADMINISTRATOR')) return message.reply('Parece que vocé não tem permissões')
      if(!args[0]) return message.reply('marque um cargo ou mande o id!')
      let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0])
      if(!role) return message.reply('cargo invalido!')
db.set(`${message.guild.id}_a`, role.id)
let embed = new Discord.MessageEmbed()
.setTitle('auto role modificado!')
.addField('modificado por', message.author)
.addField('cargo modificado para', role)
message.channel.send(embed)  
};
