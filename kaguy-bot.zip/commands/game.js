const Discord = require('discord.js');
  const db = require('quick.db');


const config = require('../config.json')
module.exports.run = async(client, message, args) => {
  if(message.guild.id !== config.suporte) return message.reply('so para o servidor de suporte!')
  let guild = message.guild;
        const embed = new Discord.MessageEmbed()
.setTitle(`Comando em manutenção`)
.setDescription(`O jogo é algo que esta em manutenção ainda`)
message.channel.send (embed)
let hehe = db.fetch(`game_${message.author.id}`)
if(hehe === "roi") return message.reply('você ja tem um jogo!')
let rsrs = await guild.roles.create({
  data: {
    name: `${message.author.username}-game`,
    color: 'BLUE',
  },
  reason: 'para o jogo rsrs',
})
let member = message.guild.members.cache.get(`${message.author.id}`)
member.roles.add(rsrs)
let TicketCategory = guild.channels.cache.get(config.he)
            let roi = await guild.channels.create(`${message.author.username}-game`, {
                type: 'text',
                parent:TicketCategory.id,
                permissionOverwrites: [
                    {
                        allow: 'VIEW_CHANNEL',
                        id: rsrs.id
                    },
                    {
                        deny: 'VIEW_CHANNEL',
                        id: guild.id
                    }
                ]
            })
            db.set(`game_${message.author.id}`, "roi")
            db.set(`channelid_${message.author.id}`,roi.id)
            db.set(`roleid_${message.author.id}`,rsrs.id)
            db.set(`owner_${message.author.id}`,roi.id)
            db.set(`code_${roi.id}`,roi.id)
            roi.send(`${message.author} o seu codigo para chama alquem para entra é... ${roi.id} !`)
}