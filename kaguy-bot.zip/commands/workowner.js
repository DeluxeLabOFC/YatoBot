const db = require('quick.db')
const Discord = require('discord.js')


exports.run = async (client, message, args) => {

   if (message.author.id === '681532724045283429' || message.author.id === '427612840078213120'){
               let user = message.author;
        let timeout = 0;
        let author = await db.fetch(`worked_${message.guild.id}_${user.id}`);
                if(author !== null && timeout - (Date.now() - author) > 0){
            let time = ms(timeout - (Date.now() - author));
            return message.channel.send(`você não pode trabalhor po ${time.minutes}m e ${time.seconds}s`)
        } else {
        
let number = Math.floor(Math.random() * 999999999999999) + 9999
let trabalhos = [
      "dev",
      "mecanico",
      "Dentista",
      "Biológio"
      ];
      let response =
        trabalhos[Math.floor(Math.random() * trabalhos.length - 1)];
        if(response === undefined) response = "Criador de site"
const embed = new Discord.MessageEmbed()
.setColor('RANDOM')
.setDescription(`${message.author} você trabalhou como ${response} e ganhou ${number}`)
message.channel.send(embed)
db.add(`KaCoins_${user.id}`,number)
db.set(`worked_${message.guild.id}_${user.id}`, Date.now())
   }
   }else return message.reply('so os devs!!')
}
