const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async(client, message, args) =>{
if(message.author.id == "681532724045283429"){
  if(!args[0]) return message.reply('qual codigo personalizado você quer? troque o spaço por _ ou - ')
let result = args[0]
let role = message.guild.roles.cache.get(args[1])
if(!role) return message.reply('você precisa coloca um id de um cargo para pode funciona!')
let o = role.id
db.set(`${result}_756685535195562075`, o)
let roi = db.fetch(`${result}_756685535195562075`)

let limite;
if(!args[2]){
  limite = 1
}else limite = args[2]
db.set(`${result}v_756685535195562075`, limite)
db.set(`${result}o__756685535195562075`, message.author.id)
    message.author.send(`${message.author}, aqui o seu key! ${result}\n\ premium: ${role.name} \n\ com limite de: ${limite} pessoas!`)
}else if(message.author.id === "427612840078213120"){
  if(!args[0]) return message.reply('qual codigo personalizado você quer? troque o spaço por _ ou - ')
let result = args[0]
let role = message.guild.roles.cache.get(args[1])
if(!role) return message.reply('você precisa coloca um id de um cargo para pode funciona!')
let o = role.id
db.set(`${result}_756685535195562075`, o)
let roi = db.fetch(`${result}_756685535195562075`)

let limite;
if(!args[2]){
  limite = 1
}else limite = args[2]
db.set(`${result}v_756685535195562075`, limite)
db.set(`${result}o__756685535195562075`, message.author.id)
    message.author.send(`${message.author}, aqui o seu key! ${result}\n\ premium: ${role.name} \n\ com limite de: ${limite} pessoas!`)
}else return message.reply('so para devs!')
}
