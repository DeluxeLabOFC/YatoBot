const Discord = require('discord.js')
const db = require('quick.db')
module.exports.run = async(client, message, args) =>{
      if (!message.member.hasPermission('ADMINISTRATOR')) return message.reply('Parece que vocé não tem permissões')
const hey = args.join(' ')
if(!hey) return message.reply('para qual mensage você quer muda o bye? \n\ [membro] -- marca o membro \n\ [server] -- o nome to servidor \n\ [membros] -- total de membros \n\ [tag] -- tag do membro')

db.set(`exge_${message.guild.id}`, hey)    
 let member = hey.replace('[membro]',message.author)
 let server = member.replace('[server]', message.guild)  
 let total = server.replace('[membros]', message.guild.memberCount)
 let tag = total.replace('[tag]',message.author.tag)
let embed = new Discord.MessageEmbed()
.setTitle(`message de bye mudado!`)
.setDescription(`mudado para.. ${tag}`)
 message.channel.send(embed)
}