const Discord = require('discord.js');
const db = require('quick.db')

module.exports.run = async (client, message, args) => {
        if (!message.member.hasPermission('ADMINISTRATOR')) return message.reply('Parece que vocé não tem permissões')
 // assim ta bom??
let server = message.guild
let prefix = db.fetch(`prefix_${server.id}`)
if(prefix === null) prefix = "k!"
  if(!args[0]) return message.channel.send('qual o novo prefix que você quer? não pode ter espaços!')
  let pe = args[0]
  message.channel.send('prefix mudado para ' + `${args[0]}`)
  db.set(`prefix_${server.id}`, args[0])
};//feito agora so modifca o index :p
/*
hehe

Modifcia o index pra? pera TOOOLLLLLLLLLLLLLLLLLLL

..... o setprefix funfu?;-; "funfu = funciona"
NÃO APAGA O JSON.SQLITE!!
ele é do quick.db!!










*/