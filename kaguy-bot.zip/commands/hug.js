const Discord = require("discord.js");
const api = require("nekos.life");
const nekos = new api()

exports.run = async(client,message,args) => {
    let membro = message.mentions.users.first() || client.users.cache.get(args[0])
    nekos.sfw.hug().then(async neko => {
        if(!membro){
            message.reply(`Não tem um amiguin para abraçar e viver feliz que sad`)
            const embed = new Discord.MessageEmbed()
            .setDescription(`dei um abraço em ${message.author}`)
            .setImage(neko.url)
            message.channel.send(embed)
        }else{
            const embed = new Discord.MessageEmbed()
            .setDescription(`${message.author} acaba de abraçar ${membro}`)
            .setImage(neko.url)
            message.channel.send(embed)
        }
    })
}

exports.help = {
    name: "hug",
    aliases: "abraçar"
}