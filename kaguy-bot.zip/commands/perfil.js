const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async (client, message, args) => {
  let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
   
  let mim = db.get(`${user.id}_mim`)
  if(mim === null || mim === 'null') mim = 'mude o seu sobre voce usando "k!sobremim"'
if(user.id === '756685259097243658') mim = 'kaguy bot feito por jose e kakashinho! coloque ja eu no seu servidor!'
if(user.id === '681532724045283429' || user.id === '427612840078213120'){
        const embed = new Discord.MessageEmbed()
.setTitle(`Seu Perfil...`)
.setDescription(`**Name:**\n${user} \n **Id:**\n${user.id}\n **Sobre você:**\n ${mim}`)
.setFooter('dono do kaguy!')
message.channel.send(embed)
}else if(user.id === '756685259097243658') {
        const embed = new Discord.MessageEmbed()
.setTitle(`Seu Perfil...`)
.setDescription(`**Name:**\n${user} \n **Id:**\n${user.id}\n **Sobre você:**\n ${mim}`)
.setFooter('Kaguy original!')
message.channel.send(embed)
  } else{
        const embed = new Discord.MessageEmbed()
.setTitle(`Seu Perfil...`)
.setDescription(`**Name:**\n${user} \n **Id:**\n${user.id}\n **Sobre você:**\n ${mim}`)
message.channel.send(embed)
}
}