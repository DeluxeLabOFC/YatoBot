const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async(client, message, args) => {
  let premium = db.fetch(`premium_${message.author.id}`)
  if(premium === null) premium === "não comprado"
  else premium = "comprado"

let embed = new Discord.MessageEmbed()
.setColor('RANDOM')
.addField(`loja de dinheiro real`, `[clique aqui](https://donatebot.io/checkout/756685535195562075?buyer=681532724045283429)`)
.addField(`loja de dinheiro do bot`,`Premium = 1.000k$: ${premium}`)
message.channel.send(embed)
}