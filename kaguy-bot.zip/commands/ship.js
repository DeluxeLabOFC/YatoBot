const { MessageEmbed } = require("discord.js");
const db = require('quick.db')
const Discord = require('discord.js')
module.exports.run = async (client, message, args) => {
 let user = message.guild.members.cache.get(args[0]) || message.mentions.members.first();
  let user2 = message.guild.members.cache.get(args[1]);
  if (!user){
   return message.reply('com quem você quer para shipa?')
  }
  if (!user2){
    return message.reply('com quem você quer shipa essa pessoa?')
  }
    
    else {
      let responses = [
        "100% [████████████████████]",
        "95% [███████████████████.]",
        "90% [██████████████████..]",
        "85% [█████████████████...]",
        "80% [████████████████....]",
        "75% [███████████████.....]",
        "70% [██████████████......]",
        "65% [█████████████.......]",
        "60% [████████████........]",
        "55% [███████████.........]",
        "50% [██████████..........]",
        "45% [█████████...........]",
        "40% [████████............]",
        "35% [███████.............]",
        "30% [██████..............]",
        "25% [█████...............]",
        "20% [████................]",
        "15% [███.................]",
        "10% [██..................]",
        "5% [█...................]",
        "0% [....................]"
      ];

      
      let response =
        responses[Math.floor(Math.random() * responses.length - 1)];
        let hi = "💖 Hmmm, será que nós temos um novo casal aqui? 💖"
              if(user2.id === "756707390329716767"){
                response = "0% [....................]"
                hi = "O essa é minha esposa >:("
        if(user.id === "756685259097243658"){ 
          response = "100% [████████████████████]"
        hi = "minha esposa(o) é linda(o) rsrsrsrs"
        }
              }else if(user2.id === "756685259097243658"){
                 response = "0% [....................]"
                 hi = "o esse é meu esposo >:("
                if(user.id === "756707390329716767"){ 
                  response = "100% [████████████████████]"
                hi = "minha esposa(o) é linda(o) rsrsrsrs"
                }
              }
      
       let embed = new MessageEmbed()
       .setColor('RANDOM')
       .setTitle(`${hi}`)
       .setDescription(`${user} \n\ ${user2}`)
       .addField('pessoa1', user,true)
       .addField('pessoa2',user2,true)
       .addField('Porcentagem de amor', response)
       message.channel.send(embed)
    }
  };
