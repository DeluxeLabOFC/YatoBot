const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {     
   const embed = new Discord.MessageEmbed()
.setTitle(`Meu site`)
.setDescription(`Site aberto ainda é novo erros é normais | [Site](https://chicletecomborrach.wixsite.com/kaguysite)`)
message.channel.send (embed)
}