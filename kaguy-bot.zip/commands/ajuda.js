const Discord = require('discord.js')

module.exports.run = async(client, message, args) =>{
       const embed = new Discord.MessageEmbed()
.setTitle(`Opções de comandos`)
.setDescription(`
🤖 | Moderação

⚽ | Diversão

💳 | Economia

🎶 | Musica

📋 | Informações

🎈 | Jogo Kaguy

Caso precise de mais alguma ajuda Suporte
[Server_Suporte](https://discord.gg/7bgx3y9)`)
const oi = await message.channel.send(embed)
oi.react('◀')
oi.react('🤖')
oi.react('⚽')
oi.react('💳')
oi.react('🎶')
oi.react('📋')
oi.react('🎈')
      let filtro1 = (r, u) => r.emoji.name === '◀' && u.id === message.author.id;
            let filtro2 = (r, u) => r.emoji.name === '🤖' && u.id === message.author.id;
                  let filtro3 = (r, u) => r.emoji.name === '⚽' && u.id === message.author.id;
                        let filtro4 = (r, u) => r.emoji.name === '💳' && u.id === message.author.id;
                              let filtro5 = (r, u) => r.emoji.name === '🎶' && u.id === message.author.id;
                                    let filtro6 = (r, u) => r.emoji.name === '📋' && u.id === message.author.id;
                                    let filtro7 = (r, u) => r.emoji.name === '🎈' && u.id === message.author.id
      let coletor1 = oi.createReactionCollector(filtro1);
      let coletor2 = oi.createReactionCollector(filtro2);
      let coletor3 = oi.createReactionCollector(filtro3);
      let coletor4 = oi.createReactionCollector(filtro4);
      let coletor5 = oi.createReactionCollector(filtro5);
         let coletor6 = oi.createReactionCollector(filtro6);
         let colletor7 = oi.createReactionCollector(filtro7);

         coletor1.on('collect', c =>{
           oi.edit(embed)
         }) 
         coletor2.on('collect',c =>{
            const moderação = new Discord.MessageEmbed()
            .setTitle('Comandos de Moderação')
            .setDescription(`
            setexit

            setlogs

            setprefix

            setwelcome

            sorteio

            say

            clear

            enquete

            setbemvindo -- setar a menssage quando alquem entra!

            setsaida -- setar menssage quando alquem sair!

            setautorole -- setar o cargo que o bot ira ta automaticamente!
            
            config
            `)
            oi.edit(moderação)
         }) 
         coletor3.on('collect',c =>{
           const diversao = new Discord.MessageEmbed()
           .setTitle('Comandos de Diversão')
           .setDescription(`
           avatar

           binario

          coinflip

          convite

          decode
 
          emoji

          hack

          hug

          kiss

          meme

          ship

          slap

          laranjo
           `)    
           oi.edit(diversao)  
         })                                 
            coletor4.on('collect', c =>{
              const economia = new Discord.MessageEmbed()
              .setTitle('Comandos de Economia')
              .setDescription(`
              balança

              buy

              daily

              work

              workvip

              loja
              `)
              oi.edit(economia)
            })
            coletor5.on('collect',c =>{
          const musica = new Discord.MessageEmbed()
          .setTitle('Comandos de Musica')
          .setDescription(`
          play

          lista

          loop

          pause

          resume

          skip

          stop

          remove

          volume -- comando so para os planos rato!
          `)
          oi.edit(musica)
            })
            coletor6.on('collect',c =>{
          const info = new Discord.MessageEmbed()
          .setTitle('Comandos de Info')
          .setDescription(`
          criador

          convite

          ping

          meuid
          
          site 

          suporte

          perfil -- comando novo

          sobremim -- comando novo feito para o comando \`perfil\`
          `)
          oi.edit(info)
            })
            colletor7.on('collect',c =>{
              const jogo = new Discord.MessageEmbed()
              .setTitle('Jogo Kaguy')
              .setDescription(`
              game -- para cria um novo jogo! 

              joingame -- para entra em um jogo!

              kickgame -- para kicka um membro do seu jogo!

              stopgame -- para parar o jogo!

              aceita -- para aceita alquem no seu jogo!
              `)
              oi.edit(jogo)
            })
}