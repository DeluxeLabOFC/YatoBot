let Discord = require('discord.js')
let db = require('quick.db')

module.exports.run = async(client, message, args) =>{
        if (!message.member.hasPermission('ADMINISTRATOR')) return message.reply('sem permissão')
        let tag2;
        let tag;
  let member = message.author
  let server = message.guild
  let roleid = db.fetch(`${server.id}_a`)//autorole
  let canalid = db.fetch(`id_${server.id}`)//welcome
let teste = db.fetch(`welge_${message.guild.id}`) // mensage boas-vindas
let teste2 = db.fetch(`exge_${message.guild.id}`)
  let canalid2 = db.fetch(`id2_${server.id}`)//bye
  let prefix = db.get(`prefix_${server.id}`);//prefix
  if(roleid === null){ roleid = 'não configurado'
  }else{
   roleid = message.guild.roles.cache.get(db.fetch(`${server.id}_a`))
  }
    if(prefix === null) prefix = 'k!'
      if(canalid2 === null) {canalid2 = 'não configurado'
      }else{
        canalid2 = message.guild.channels.cache.get(canalid2)
      }
        if(canalid === null) {canalid = 'não configurado'
        }else {
          canalid = message.guild.channels.cache.get(canalid)
        }

      

 if(teste !== null){
 let membro = teste.replace('[membro]',member)
 let server2 = membro.replace('[server]', message.guild)  
 let total = server2.replace('[membros]', message.guild.memberCount)
  tag = total.replace('[tag]',member.tag)
 }else if (teste === null) {
    tag = 'não configurado' 
   }else  tag = "não configurado"
 if(teste2 !== null){
   let hey2 = teste2
 let membro2 = hey2.replace('[membro]',member)
 let server22 = membro2.replace('[server]', message.guild)  
 let total2 = server22.replace('[membros]', message.guild.memberCount)
  tag2 = total2.replace('[tag]',member.tag)
 }else if (teste2 === null) {
    tag2 = "não configurado"
 }else {
    tag2 = "não configurado"
 }
 let embed = new Discord.MessageEmbed()
 .setDescription(`${server.name} configuração`)
 .addField(`prefix`, prefix)
 .addField(`canal welcome`, canalid)
.addField('canal bye', canalid2)
.addField('mensage boas-vindas', tag)
.addField('mensage de tchau', tag2)
.addField('autorole', roleid)
message.channel.send(embed)
}