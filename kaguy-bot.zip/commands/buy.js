const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async(client, message, args) => {
let KaCoins = db.fetch(`KaCoins_${message.author.id}`)
if(KaCoins === null || KaCoins === 0)return message.reply('você não tem dinheiro para pode compra algo!')
const oq = args[0]
if(!oq){
  return message.reply('você tem que fala oque você quer compra!')
}
if(oq === "Premium"|| oq === "premium"){
  let premium = db.fetch(`premium_${message.author.id}`)
  if(premium === null){
  if(KaCoins >= 1000){
    message.reply('Você comprou o Premium')
    let  min = "1000"
 let max = `${KaCoins}`
  let hi = Math.floor(max - min);
 db.set(`KaCoins_${message.author.id}`, hi)
 db.set(`premium_${message.author.id}`, 1)
  }else {
    return message.reply('você não tem 1000 ou mais de KaCoins!')
  }
    }else return message.reply("você sa comprou o premium!")
}

}