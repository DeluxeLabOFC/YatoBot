const Discord = require("discord.js");
const api = require("nekos.life");
const nekos = new api()

exports.run = async(client,message,args) => {
    let membro = message.mentions.users.first() || client.users.cache.get(args[0])
    nekos.sfw.kiss().then(async neko => {
        if(!membro){
            message.reply(`Sinto muito mas você não pode se beijar ,_,`)
        }else{
            const embed = new Discord.MessageEmbed()
            .setDescription(`${message.author} acaba de beijar ${membro}`)
            .setImage(neko.url)
            message.channel.send(embed)
        }
    })
}

exports.help = {
    name: "kiss",
    aliases: "beijar"
}