let Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async(client, message, args) =>{

let roi = args.join(' ');
if(!roi) return message.reply('oque você quer coloca no seu sobre mim?')
db.set(`${message.author.id}_mim`, roi)
let embed = new Discord.MessageEmbed()
.setAuthor(message.author.tag,message.author.displayAvatarURL())
.setDescription('sobre você mudado para: ' + roi)
message.channel.send(embed)
}