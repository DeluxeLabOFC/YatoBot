const Discord = require('discord.js')

exports.run = async (client, message, args) => {
  let embed = new Discord.MessageEmbed() 
    .setColor(`RANDOM`) 
    .setTitle(`Eu estou em`)
    .setDescription(`${client.guilds.cache.size} servers!!`)
    .setFooter(`Autor: ${message.author.tag} :D`, message.author.displayAvatarURL({format: "png"}));
 await message.channel.send(embed); 

};