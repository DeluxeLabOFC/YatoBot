require('dotenv').config();
const Discord = require("discord.js"); 
const client = new Discord.Client();
const { readdirSync } = require('fs');
const { join } = require('path');
const commandFiles = readdirSync(join(__dirname, 'commands')).filter(file => file.endsWith('.js'));

const Collection = require("discord.js");
client.queue = new Map()
module.exports = client;
const express = require('express');
const app = express();
app.get("/", (request, response) => {
  const ping = new Date();
  ping.setHours(ping.getHours() - 3);
  console.log(`Ping recebido às ${ping.getUTCHours()}:${ping.getUTCMinutes()}:${ping.getUTCSeconds()}`);
  response.sendStatus(200);
});
app.listen(process.env.PORT); // Recebe solicitações que o deixa online

//Conexão com a livraria Discord.js //Criação de um novo Client
const config = require("./config.json"); //Pegando o prefixo do bot para respostas de comandos
const db = require('quick.db')


client.on("ready", () => {
  console.log('Inciado com sucesso!')
})



client.on('message', message => {
     if (message.author.bot) return;
     if (message.channel.type == 'dm') return;
  let oi = message.guild.id
  let prefix = db.get(`prefix_${oi}`) || 'k!';
  if(prefix === null) prefix = "k!"
       if (message.content.startsWith(`<@!756685259097243658>`) || message.content.startsWith(`<@756685259097243658>`)){
       let embed = new Discord.MessageEmbed()
       .setColor('RANDOM')
       .setAuthor(message.author.tag , message.author.displayAvatarURL())
       .setDescription(`ola! ${message.author}, meu prefix nesse servidor é \`${prefix}\``)
       .setFooter(`Executado por ${message.author.tag}`)
       .setTimestamp()
        message.channel.send(embed)
     };
     if (!message.content.toLowerCase().startsWith(prefix.toLowerCase())) return;

    const args = message.content
        .trim().slice(prefix.length)
        .split(/ +/g);
    const command = args.shift().toLowerCase();
   
    try {
      if(!command) return message.reply('qual comando você quer usa?')
        const commandFile = require(`./commands/${command}.js`)
        commandFile.run(client, message, args);
    } catch (err) {
    console.error('Erro:' + err);
    const embed = new Discord.MessageEmbed()
.setTitle(` `)
.setDescription(`> O comando \`${command}\` não existe. \n> Utilize \`${prefix}ajuda\` para receber ajuda.`)
.setColor(`#585858`)
message.channel.send (embed)
  }

});
client.on('guildMemberAdd', member => {  
  let server = member.guild
let roleid = db.fetch(`${server.id}_a`)
  if(roleid === null) return
 let role = server.roles.cache.get(roleid)
member.roles.add(role)
})
client.on('guildMemberAdd', member => {  
  let server = member.guild
  let canalid = db.fetch(`id_${server.id}`)
  if(canalid === null) return
let teste = db.fetch(`welge_${member.guild.id}`)
if(teste === null){
   let embed = new Discord.MessageEmbed()
   .setColor('RANDOM')
   .setAuthor('bem-vindo(a)',member.user.displayAvatarURL())
     .setDescription(`${member} bem-vindo(a) ao nosso servidor!! ${member.guild.name} espero que goste :3`)
   member.guild.channels.cache.get(canalid).send(embed);
}else{
  let hey = teste
 let membro = hey.replace('[membro]',member)
 let server = membro.replace('[server]', member.guild)  
 let total = server.replace('[membros]', member.guild.memberCount)
 let tag = total.replace('[tag]', `${member.user.tag}`)
    let embed = new Discord.MessageEmbed()
   .setColor('RANDOM')
   .setAuthor('bem-vindo(a)',member.user.displayAvatarURL())
     .setDescription(`${tag}`)
   member.guild.channels.cache.get(canalid).send(embed);
}
  });

client.on("messageDelete", message => {
  let server = message.guild
 let canalid3 = db.fetch(`id3_${server.id}`)
return
})

client.on('guildMemberRemove', member => {
  let server = member.guild
  let canalid2 = db.fetch(`id2_${server.id}`)
  if(canalid2 === null) return
let teste = db.fetch(`exge_${server.id}`)
if(teste === null){
  let embed2 = new Discord.MessageEmbed()
  .setColor('RANDOM')
  .setAuthor('ate mais..',member.user.displayAvatarURL())
  .setDescription(`${member} saiu do servidor ${member.guild.name} espero que ele volte!!`)
  
    member.guild.channels.cache.get(canalid2).send(embed2);
}else{
    let hey = teste
 let membro = hey.replace('[membro]',member)
 let server = membro.replace('[server]', member.guild)  
 let total = server.replace('[membros]', member.guild.memberCount)
 let tag = total.replace('[tag]', `${member.user.tag}`)
   let embed2 = new Discord.MessageEmbed()
  .setColor('RANDOM')
  .setAuthor('ate mais..',member.user.displayAvatarURL())
  .setDescription(tag)
      member.guild.channels.cache.get(canalid2).send(embed2);
}
  });  

          
client.on("ready", () => {
  let activities = [
      `Versão 1.13.4 | ${config.prefix}ajuda para receber ajuda`,
      `${client.guilds.cache.size} servidores!  | Prefixo ${config.prefix}`,
      `${client.channels.cache.size} canais!  | Prefixo ${config.prefix}`,
      `${client.users.cache.size} usuários!  | ${config.prefix}ajuda`,
      `Caso alguma duvida Server suporte ou Obvermos#0018`,
      `Prefixo ${config.prefix} | Quem sabe viro verificado um dia`,
      `My prefix ${config.prefix}`,
      `Se eu ficar off sem avisar é um problema ou é update :D`,
      `Meu prefixo ${config.prefix} pode ser mudado em seu server verifique`,
      `Shoryuken | só quem é gamer das antigas tendeu : Prefixo ${config.prefix}`,
      `Rasengan | Quem tendeu assisti anime : Prefixo ${config.prefix}`,
      `Logo logo um dos meus donos terá canal viu`,
      `Prefixo ${config.prefix} | Saiba alguns dos meus secredos em meu server suporte`,
      `${client.guilds.cache.size} servidores!  | Prefixo ${config.prefix}`,
      `${client.channels.cache.size} canais!`,
      `${client.users.cache.size} usuários!  | Prefixo ${config.prefix}`,
    ],
    i = 0;
  setInterval( () => client.user.setActivity(`${activities[i++ % activities.length]}`, {
        type: "WATCHING"
      }), 20000); 
  client.user
      .setStatus("dnd")
      .catch(console.error);
console.log("Estou Online!")
});

const votosZuraaa = require('./votosZuraaa.js');

client.on('message', message => {
    votosZuraaa.verificaVotos(message, function(user){
        // Modifique este bloco de acordo com a função que você deseja
        
        
        let canal = client.channels.cache.get("760469157786550334");
        
        let vlw = new Discord.MessageEmbed()
     .setTitle("alquem votou em mim!")
     .setDescription(`\`${user.username}\` Muito obrigado por vota em mim!! quando mais voto eu ganho mais popular eu vou ser!! 
     quem quiser ajuda pode vota em mim tambem!
     
**Vote em mim também:**
[Kaguy](https://zuraaa.com/bots/756685259097243658)`)
    
     
        canal.send(vlw);
      
     
    });
})



client.login(config.token) 